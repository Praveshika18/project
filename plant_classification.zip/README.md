# Traditional Image Classification - Plant Pathology 2020

This project uses handcrafted features and traditional machine learning models to classify plant leaf images into categories.

## 📊 Categories
- Healthy
- Multiple Diseases
- Rust
- Scab

## 🧠 Models Used
- Support Vector Machines (SVM)
- Random Forest
- Gradient Boosting Machines

## 📦 Folder Structure
```
plant_classification/
├── data/
├── features/
├── models/
├── notebooks/
├── results/
├── scripts/
├── main.py
├── requirements.txt
└── README.md
```

## 🚀 How to Run
1. Extract features using `scripts/feature_extraction.py`
2. Train the model using `scripts/train_model.py`
3. Evaluate the model using `scripts/evaluate_model.py`
